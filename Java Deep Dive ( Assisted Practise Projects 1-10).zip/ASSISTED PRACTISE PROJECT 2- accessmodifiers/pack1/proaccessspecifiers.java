package pack1;

public class proaccessspecifiers {
	protected void display() 
    { 
        System.out.println("This is protected access specifier"); 
    } 
}


